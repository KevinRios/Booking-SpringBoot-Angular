
--------------------------------------------------------------
-- INSERT INTO RESTAURANT
--------------------------------------------------------------

INSERT INTO `BOOKING_RESTAURANT`.`RESTAURANT` (`ID`, `NAME`, `DESCRIPTION`, `ADRESS`, `IMAGE`) VALUES ('1', 'KFC', 'Pollo Frito', 'Calle01', 'https://upload.wikimedia.org/wikipedia/commons/e/ef/Restaurant_Näsinneula.jpg');
INSERT INTO `BOOKING_RESTAURANT`.`RESTAURANT` (`ID`, `NAME`, `DESCRIPTION`, `ADRESS`, `IMAGE`) VALUES ('2', 'BK', 'Hamburguesas', 'Calle02', 'https://media-cdn.tripadvisor.com/media/photo-s/1a/18/3a/cb/restaurant-le-47.jpg');


--------------------------------------------------------------
-- INSERT INTO TURN
--------------------------------------------------------------
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('1', 'TURNO_10', '1');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('2', 'TURNO_11', '1');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('3', 'TURNO_12', '1');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('4', 'TURNO_13', '1');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('5', 'TURNO_10', '2');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('6', 'TURNO_11', '2');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('7', 'TURNO_12', '2');
INSERT INTO `BOOKING_RESTAURANT`.`TURN` (`ID`, `NAME`, `RESTAURANT_ID`) VALUES ('8', 'TURNO_13', '2');


--------------------------------------------------------------
-- INSERT INTO BOARD
--------------------------------------------------------------

INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('1', '3', '1', '1');
INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('2', '6', '2', '1');
INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('3', '2', '3', '1');
INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('4', '5', '4', '1');
INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('5', '4', '1', '2');
INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('7', '4', '3', '2');
INSERT INTO `BOOKING_RESTAURANT`.`BOARD` (`ID`, `CAPACITY`, `NUMBER`, `RESTAURANT_ID`) VALUES ('8', '8', '4', '2');


--------------------------------------------------------------
-- INSERT INTO RESERVATION
--------------------------------------------------------------

INSERT INTO `BOOKING_RESTAURANT`.`RESERVATION` (`ID`, `LOCATOR`, `PERSON`, `DATE`, `TURN`, `RESTAURANT_ID`) VALUES ('1', 'KFC', '6', '2020-12-31', 'TURNO_10', '1');
